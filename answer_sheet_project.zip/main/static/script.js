const structure = document.getElementById('structure')
const radio_tags = document.getElementById('radio')
const RadioTag_simple = document.getElementById('simple')
const RadioTag_linear = document.getElementById('linear')
const RadioTags_tyype = document.getElementById('type_tags')
const html_tag = document.querySelector('html')
const Theme = document.getElementById('Theme')
const callme = document.getElementById('callme')
const Information = document.getElementById('Information')
const Radio_tag_p_1 = document.getElementById('Radio-tag-p-1')
const Radio_tag_p_2 = document.getElementById('Radio-tag-p-2')
const Radio_tag_img_1 = document.getElementById('Radio-tag-img-1')
const Radio_tag_img_2 = document.getElementById('Radio-tag-img-2')
const Radio_tag_1 = document.getElementById('one');
const Radio_tag_2 = document.getElementById('two');
const HelperPlus = document.getElementById('helper_plus');
const helper = document.getElementById('helper');
const sub = document.getElementById('sub');
const sub_button = document.getElementsByClassName('sub')[0];
const last_choose = document.getElementsByClassName('last-choose')[0];
const HiddenInput = document.getElementById('HiddenInput')
const hidden_last = document.getElementById('hidden-last')

function hidden(clas, dis) {
    let tag = document.querySelectorAll(`.${clas}`)

    tag.forEach(element => {
        element.style.display = `${dis}`
    });
}

//checking - the local storage
if (localStorage.getItem('theme') == 'dark') {
    them('dark')
} else if (localStorage.getItem('theme') == 'light') {
    them('light')
}
//function - theme
function them(theme) {
    if (theme == 'dark') {
        html_tag.className = '';
        Theme.className = 'icon bi-moon';
        localStorage.setItem('theme', 'dark')
    } else if (theme == 'light') {
        html_tag.className = 'light';
        Theme.className = 'icon bi-sun';
        localStorage.setItem('theme', 'light')
    }

};

//Theme
Theme.addEventListener('click', () => {
    if (html_tag.className == 'light') {
        them('dark');
    } else if (html_tag.className == '') {
        them('light');
    };
});
//callme
callme.addEventListener('click', () => {
    if (callme.className == 'icon bi-envelope') {
        hidden('form', 'none');
        hidden('callme', 'flex');
        callme.className = 'icon bi-arrow-90deg-left'
    } else if (callme.className == 'icon bi-arrow-90deg-left') {
        hidden('form', 'flex');
        hidden('callme', 'none');
        callme.className = 'icon bi-envelope'
    }
});
//Information
Information.addEventListener('click', () => {
    if (Information.className == 'icon bi-question-circle') {
        hidden('form', 'none');
        hidden('help-me', 'flex');
        Information.className = 'icon bi-arrow-90deg-left'
    } else if (Information.className == 'icon bi-arrow-90deg-left') {
        hidden('form', 'flex');
        hidden('help-me', 'none');
        Information.className = 'icon bi-question-circle'
    }
});
//زیر محور پاسخبرگ
radio_tags.addEventListener('click', () => {
    console.log(RadioTag_linear.checked);


    if (RadioTag_linear.checked == true) {
        RadioTags_tyype.style.display = 'flex'
        Radio_tag_p_1.style.background = 'var(--radio-bg)'
        Radio_tag_p_1.style.color = 'var(--text)'
        Radio_tag_p_2.style.background = 'var(--radio-bg)'
        Radio_tag_p_2.style.color = 'var(--text)'
        Radio_tag_p_2.innerHTML = 'تشریحی'
        Radio_tag_img_1.setAttribute('src', 'https://s8.uupload.ir/files/screenshot_(110)_4fgl.png')
        Radio_tag_1.setAttribute('value', 'solution')
        Radio_tag_p_1.innerHTML = 'تستی'
        Radio_tag_img_2.setAttribute('src', 'https://s8.uupload.ir/files/screenshot_(111)_xnt2.png')
        Radio_tag_2.setAttribute('value', 'anatomical')
        hidden('rows', 'flex');
    } else if (RadioTag_simple.checked == true) {
        Radio_tag_p_1.style.background = 'var(--radio-bg)'
        Radio_tag_p_1.style.color = 'var(--text)'
        Radio_tag_p_2.style.background = 'var(--radio-bg)'
        Radio_tag_p_2.style.color = 'var(--text)'
        RadioTags_tyype.style.display = 'flex'
        Radio_tag_img_1.setAttribute('src', 'https://s8.uupload.ir/files/screenshot_(108)_n3cd.png')
        Radio_tag_p_1.innerHTML = 'ابداعی'
        Radio_tag_1.setAttribute('value', 'inventive')
        Radio_tag_img_2.setAttribute('src', 'https://s8.uupload.ir/files/screenshot_(109)_id7l.png')
        Radio_tag_p_2.innerHTML = 'استاندارد'
        Radio_tag_2.setAttribute('value', 'Standard')
        hidden('rows', 'none');
    };
});

//radio_tags_hover_and selected
RadioTags_tyype.addEventListener('click', () => {
    if (Radio_tag_1.checked == true) {
        RadioTags_tyype.children[0].children[0].children[1].style.background = 'var(--radio-bg-hover)'
        RadioTags_tyype.children[0].children[0].children[1].style.color = 'black'

        RadioTags_tyype.children[1].children[0].children[1].style.background = 'var(--radio-bg)'
        RadioTags_tyype.children[1].children[0].children[1].style.color = 'var(--text)'
        sub_button.innerHTML = '<button type="submit"> ساخت پاسخبرگ</button>'
    } else if (Radio_tag_2.checked == true) {
        RadioTags_tyype.children[0].children[0].children[1].style.background = 'var(--radio-bg)'
        RadioTags_tyype.children[0].children[0].children[1].style.color = 'var(--text)'

        RadioTags_tyype.children[1].children[0].children[1].style.background = 'var(--radio-bg-hover)'
        RadioTags_tyype.children[1].children[0].children[1].style.color = 'black'
        if (Radio_tag_2.value == 'anatomical') {
            hidden('helper', 'flex');
            helper.style.height = `15vh`;
            document.getElementsByClassName('helper')[0].style.height = `15vh`;

        }
        if (Radio_tag_2.value == 'Standard') {
            sub_button.innerHTML = '<p id="sub_button"> ساخت پاسخبرگ</p>'
            const sub_main_button = document.getElementById('sub_button');
            sub_main_button.addEventListener('click', () => {
                hidden('form', 'none');
                hidden('last-choose', 'flex');
            })
        } else {
            sub_button.innerHTML = '<button type="submit"> ساخت پاسخبرگ</button>'
        }

    }

});

last_choose.children[0].addEventListener('click', () => { hidden_last.value = 'pdf'; let help = { 0: 0 }; HiddenInput.value = JSON.stringify(help); sub.submit() })
last_choose.children[1].addEventListener('click', () => { hidden_last.value = 'html'; let help = { 0: 0 }; HiddenInput.value = JSON.stringify(help); sub.submit() })
// extra helpers
let height = 15;
HelperPlus.addEventListener('click', () => {
    helper.innerHTML += `                    <div class="input">
                        <input type="number" class="input_tag helper_input_tag helper_input_tag_1 " name="helper" id="helper">
                        <p> : </p>
                        <input type="number" class="input_tag helper_input_tag helper_input_tag_2" name="helper" id="helper">
                        </div>`;

    helper.style.height = `${height}vh`;
    document.getElementsByClassName('helper')[0].style.height = `${height}vh`;
    height += 5
});

sub.addEventListener('submit', (e) => {
    e.preventDefault();
    const helpertags1 = document.getElementsByClassName('helper_input_tag_1')
    const helpertags2 = document.getElementsByClassName('helper_input_tag_2')


    let help = { 0: 0 };

    for (let i = 0; i < helpertags1.length; i++) {
        help[helpertags1[i].value] = helpertags2[i].value;
    }

    HiddenInput.value = JSON.stringify(help)
    console.log(HiddenInput.value);


    sub.submit();
})